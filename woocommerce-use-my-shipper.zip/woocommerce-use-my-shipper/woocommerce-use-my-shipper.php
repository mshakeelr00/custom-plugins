<?php
/*
Plugin Name: WooCommerce Use My Shipper
Plugin URI:  https://ignitewoo.com/
Description: Allows shoppers to opt to have their order shipped using their own shipper account number
Version: 3.8.2
Author: IgniteWoo.com
Author URI: https://ignitewoo.com/
Text Domain: woocommerce
Domain Path: languages/
WC requires at least: 4.0
WC tested up to: 9.5.3
X-IGN-ID: 10773
X-IGN-Signature: be99e94cf92f28b5af3d848efd9bac73

Copyright (c) 2014 - 2025 - IgniteWoo.com -- ALL RIGHTS RESERVED

*/
if (!function_exists('is_woocommerce_active')){
        function is_woocommerce_active(){
            $active_plugins = (array) get_option('active_plugins', array());
            if(is_multisite()){
                   $active_plugins = array_merge($active_plugins, get_site_option('active_sitewide_plugins', array()));
            }
            return in_array('woocommerce/woocommerce.php', $active_plugins) || array_key_exists('woocommerce/woocommerce.php', $active_plugins);
        }
}

class IGN_Use_My_Shipper_Base { 

	public $scripts_loaded;
	
	function __construct() { 

		add_action( 'init', array( &$this, 'use_my_shipper_init' ), 999 );
		
		add_action( 'wp_loaded', array( &$this, 'maybe_clear_ums_sessions_vars' ), 9 );
		
		add_action( 'woocommerce_checkout_order_processed', array( &$this, 'add_shipper_info_to_order' ), 1, 2 );
		add_action( 'woocommerce_email_order_meta', array( &$this, 'maybe_add_to_emails' ), 1, 4 );

		add_action( 'woocommerce_shipping_init', array( &$this, 'init_use_my_shipping' ) );
		add_filter( 'woocommerce_shipping_methods', array( &$this, 'add_use_my_shipper_method' ), 9999 );
		
		add_filter( 'woocommerce_shipping_packages', array( &$this, 'ums_set_package_meta' ), -99999 );
		
		// For the cart page: 
		add_action( 'wp_ajax_woocommerce_update_shipping_method', array( &$this, 'ums_set_package_meta' ), -999 );
		add_action( 'wp_ajax_nopriv_woocommerce_update_shipping_method', array( &$this, 'ums_set_package_meta' ), -999 );
		add_action( 'wc_ajax_update_shipping_method', array( &$this, 'ums_set_package_meta' ), -999 );
		
		// For checkout - the Update Order Review action, ensure data is saved 
		add_action( 'woocommerce_checkout_update_order_review', array( &$this, 'checkout_update_order_review' ), 1, 1 );
		
		// Ensure JS code is injected on the cart page after someone selects a shipping method
		add_action( 'woocommerce_before_cart_totals', array( &$this, 'scripts' ) );
		
		add_action( 'wp_ajax_update_ums_shipper', array( &$this, 'ums_set_package_meta' ), -999 );
		add_action( 'wp_ajax_nopriv_update_ums_shipper', array( &$this, 'ums_set_package_meta' ), -999 );

		add_filter( 'woocommerce_after_shipping_rate', array( 'WC_USE_MY_SHIPPER', 'ign_use_my_shipper_new_way' ), -1, 2 ); 
		add_action( 'woocommerce_before_cart', array( &$this, 'scripts' ) );

		
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( &$this, 'ign_my_shipper_action_links' ) );
		
		// DEPRECATED, but here for backward compat: 
		// WC 3.x
		add_action( 'woocommerce_admin_order_totals_after_shipping', array( &$this, 'show_my_shipper' ), 1, 1 );
		// WC 2.1.x
		add_action( 'woocommerce_admin_order_totals_after_shipping_item', array( &$this, 'show_my_shipper' ), 1, 1 );
		
		add_action( 'woocommerce_before_checkout_form', array( $this, 'scripts' ), 1 );
		add_action( 'wp_footer', array( $this, 'scripts' ), 1 );
		$this->scripts_loaded = false;
		
		add_action( 'before_woocommerce_init', array( &$this, 'declare_hpos_compatible' ) );
	}
	
	public function declare_hpos_compatible() {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			// Not compat with cart and checkout blocks due to their limited extensibility.
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, false );
			// Compatibile with HPOS and remote logging
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'remote_storage', __FILE__, true );
		}
	}
	
	function init_use_my_shipping() { 

		if ( !class_exists( 'WC_Shipping_Method' ) ) { 
			return;
		}
		
		require_once( dirname(__FILE__) . '/class-wc-use-my-shipper.php' );
	}

	function add_use_my_shipper_method( $methods ) {
		if ( !class_exists( 'WC_USE_MY_SHIPPER' ) ) { 
			return;
		}
		$methods['use_my_shipper'] = 'WC_USE_MY_SHIPPER'; 
		return $methods;
	}

	function use_my_shipper_init() {

		if ( !function_exists( 'WC' ) ) { 
			return;
		}
		
		if ( !class_exists( 'WC_Shipping_Method' ) ) { 
			return;
		}
		
		//if ( !defined( 'DOING_AJAX' ) )
		//	return;
			
		if ( !class_exists( 'WC_USE_MY_SHIPPER' ) ) {
			require_once( dirname(__FILE__) . '/class-wc-use-my-shipper.php' );
		}

		// Deprecated January 2025 in favor of using 'woocommerce_after_checkout_validation'
		//add_action( 'wp_ajax_woocommerce_checkout', array( 'WC_USE_MY_SHIPPER', 'my_shipper_review' ), -1 );
		//add_action( 'wp_ajax_nopriv_woocommerce_checkout', array( 'WC_USE_MY_SHIPPER', 'my_shipper_review' ), -1 );
		//add_action( 'wc_ajax_checkout', array( 'WC_USE_MY_SHIPPER', 'my_shipper_review' ), -1 );
		add_action( 'woocommerce_after_checkout_validation', array( 'WC_USE_MY_SHIPPER', 'after_checkout_validation' ), 1, 2 );
		
		// For compatibility with Linear Checkout for WooCommerce by Cartimize
		add_action( 'wc_ajax_complete_order', array( 'WC_USE_MY_SHIPPER', 'my_shipper_review' ), -2 );
		add_action( 'wc_ajax_woocommerce_complete_order', array( 'WC_USE_MY_SHIPPER', 'my_shipper_review' ), -2 );
	}

	
	public function scripts() { 
		global $use_my_shipper_scripts_injected; 

		// Some sites might call the woocommerce_before_checkout_form hook many times, so prevent script from being injected more than once
		/*
		// Do it like this because sometimes other software loses context of "$this" : 
		if ( !empty( $this ) && !empty( $this->scripts_injected ) )
			return;

		if ( !empty( $use_my_shipper_scripts_injected ) ) {
			return;
		}
			
		if ( !empty( $this ) ) { 
			$this->scripts_injected = true;
			$use_my_shipper_scripts_injected = true; 
		}
		*/
		
		if ( ! function_exists( 'is_checkout' ) ) {
			return;
		}
		
		if ( ! is_checkout() && ! is_cart() ) {
			return;
		}
		
		if ( $this->scripts_loaded ) {
			return;
		}
		
		// This filter can be used to help with themes that override the standard radio buttons for shipping methods,
		// which typically occurs in themes that use custom styling for the buttons to hide the original buttons and 
		// insert their own styled buttons.
		$compat = apply_filters( 'ums_check_for_hidden_shipping_method', true );
		
		?>
		<script>
		jQuery( document ).ready( function( $ ) { 

			function check_ums() { 

				<?php if ( version_compare( WOOCOMMERCE_VERSION, '2.5', '<' ) && 'select' === get_option( 'woocommerce_shipping_method_format' ) ) { ?>
					$( '.shipping_method option:selected' ).each( function() { 
						var val = $( this ).val();
						
						if ( NaN !== val && null !== val && 'use_my_shipper' == val.substring( 0, 14 ) ) {
							btn = $( '.shipping_method option:selected' );
							btn.parent().find( 'tr#use_my_shipper, table#use_my_shipper' ).css( 'display', 'table-row' );
						} else { 
							$( this ).closest( '#shipping_method' ).find( 'tr#use_my_shipper, table#use_my_shipper' ).hide();
						}
					});
					
					
				<?php } else { ?>

					<?php if ( $compat ) { ?>
					// Check if Use My Shipper is the only shipping method available, if so it would be a hidden input field:
						var l = $( "input:hidden[class='shipping_method']");
					<?php } else { ?>
						var l = {};
					<?php } ?>

					// It's the only method? 
					if ( l.length > 0 ) { 
						$( "input:hidden[class='shipping_method']").each( function() { 
							var val = $( this ).val();

							if ( NaN !== val && null !== val && 'use_my_shipper' == val.substring( 0, 14 ) ) {
								//btn = $( '.shipping_method option:selected' );
								$( this ).closest( 'li' ).find( 'tr#use_my_shipper, table#use_my_shipper' ).css( 'display', 'table-row' );			
							} else { 
								// Hide all instances for this package
								$( this ).closest( '#shipping_method' ).find( 'tr#use_my_shipper, table#use_my_shipper' ).hide();
							}
						})
						
					// Otherwise there are other methods available
					} else { 
					
						$( '.shipping_method:checked' ).each( function() { 
							var val = $( this ).val();

							if ( NaN !== val && null !== val && 'use_my_shipper' == val.substring( 0, 14 ) ) {
								//btn = $( '.shipping_method option:selected' );
								$( this ).closest( 'li' ).find( 'tr#use_my_shipper_row, table#use_my_shipper' ).css( 'display', 'table-row' );				
							} else { 
								// Hide all instances for this package
								$( this ).closest( '#shipping_method' ).find( 'tr#use_my_shipper_row, table#use_my_shipper' ).hide();
							}
						});
					}
					
				<?php } ?>
			}
			
			check_ums();
			
			jQuery( document ).on( 'updated_checkout updated_shipping_method updated_wc_div', function() { 
				setTimeout( function() { 
					check_ums();
					ums_cart_button();
				}, 100 );
			});
		
		<?php //if ( is_cart() ) { ?>
		
			function ums_cart_button() { 

				jQuery( '.ums_shipper_button' ).unbind().on( 'click touchstart', function() { 

					jQuery( 'div.cart_totals' ).addClass( 'processing' ).block( {
						message: null,
						overlayCSS: {
							background: '#fff',
							opacity: 0.6
						}
					} );
					
					shipping_method_selected();
					
					jQuery( 'div.cart_totals' ).removeClass( 'processing' ).unblock();
				});
				
				var shipping_method_selected = function() {

					var shipping_methods = {};
					var shippers = {};
					var shipper_numbers = {};
					var shipper_notes = {};

					$( 'select.shipping_method, :input[name^=shipping_method][type=radio]:checked, :input[name^=shipping_method][type=hidden]' ).each( function() {
						shipping_methods[ $( this ).data( 'index' ) ] = $( this ).val();
					} );
			
					$( 'select.shipping_method, :input[name^=shipping_method][type=radio]:checked, :input[name^=shipping_method][type=hidden]' ).parent().find( '.shipper_name' ).each( function() {
						shippers[ $( this ).data( 'index' ) ] = $( this ).val().trim();
					} );

					$( 'select.shipping_method, :input[name^=shipping_method][type=radio]:checked, :input[name^=shipping_method][type=hidden]' ).parent().find( 'input.shipper_number' ).each( function() {
						shipper_numbers[ $( this ).data( 'index' ) ] = $( this ).val().trim();
					} );
					
					$( 'select.shipping_method, :input[name^=shipping_method][type=radio]:checked, :input[name^=shipping_method][type=hidden]' ).parent().find( 'textarea.shipper_note' ).each( function() {
						shipper_notes[ $( this ).data( 'index' ) ] = $( this ).val().trim();
					} );

					//$.block( $( 'div.cart_totals' ) );

					var data = {
						action: 'update_ums_shipper',
						security: wc_cart_params.update_shipping_method_nonce,
						shipping_method: shipping_methods,
						my_shipper: shippers,
						use_my_shipper: shipper_numbers,
						use_my_shipper_note: shipper_notes
					};
					
					$.ajax( {
						type:     'post',
						//url:      wc_cart_params.wc_ajax_url.toString().replace( '%%endpoint%%', 'update_shipping_method' ),
						url:      '<?php echo admin_url( 'admin-ajax.php' ) ?>',
						data:     data,
						dataType: 'html',
						success:  function( response ) {
							// placeholder
						},
						complete: function() {
							// currently not necessary: 
							//$( document.body ).trigger( 'updated_shipping_method' );
						}
					} );
				};
			}
			
			ums_cart_button();
		
		<?php //} ?>
		});
		</script>
		<?php
		$this->scripts_loaded = true;
	}
	
	function maybe_clear_ums_sessions_vars() { 

		if ( !function_exists( 'WC' ) || ( is_admin() && !defined( 'DOING_AJAX' ) ) ) { 
			return;
		}

		// If the cart is empty then remove any UMS session variables
		if ( empty( WC()->cart ) || WC()->cart->is_empty() ) { 
		
			if ( !empty( WC()->session ) ) { 
				$data = WC()->session->get_session_data(); 

				if ( !empty( $data ) && is_array( $data ) ) { 
				
					foreach( $data as $key => $vals ) { 
						if ( 'ums_shipping_meta' == substr( $key, 0, 17 ) ) { 
							WC()->session->__unset( $key );
						}
					}
					
					WC()->session->save_data();
				}
			}
		}
	}
		
	function checkout_update_order_review( $posted ) { 

		$chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );

		if ( isset( $_REQUEST['shipping_method'] ) && is_array( $_REQUEST['shipping_method'] ) ) {
			foreach ( $_REQUEST['shipping_method'] as $i => $value ) {
				$chosen_shipping_methods[ $i ] = wc_clean( $value );
			}
			
			WC()->session->set( 'chosen_shipping_methods', $chosen_shipping_methods ); 
		}
		
		$data = wp_parse_args( $posted );

		$saved_request = $_REQUEST; 
		$saved_post = $_POST; 
		
		foreach( $data as $key => $vals ) { 
			$_POST[ $key ] = $_REQUEST[ $key ] = $vals;
		}

		if ( !empty( $_POST['use_my_shipper'] ) && is_array( $_POST['use_my_shipper'] ) ) { 
			$this->ums_set_package_meta();
		}
	
		$_REQUEST = $saved_request;
		
		$_POST = $saved_post;
	}
	
	function ums_set_package_meta( $packages = false ) { 

		if ( empty( $_REQUEST['use_my_shipper'] ) || !is_array( $_REQUEST['use_my_shipper'] ) ) { 
			return $packages;
		}
	
		$labels = array( 
			'ship_name' => __( 'Shipper Name', 'woocommerce' ),
			'ship_acct' => __( 'Shipper Acct', 'woocommerce' ),
			'ship_note' => __( 'Shipping Note', 'woocommerce' ),
		);

		$chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );
		
		if ( empty( $chosen_shipping_methods ) ) { 
			return $packages; 
		}

		$index = -1;
		
		if ( empty( $packages ) ) { 
		
			$packages = WC()->cart->get_shipping_packages();
			
			if ( 
				( isset( $_REQUEST['action'] ) && 'update_ums_shipper' == $_REQUEST['action'] )
				||
				( isset( $_REQUEST['wc-ajax'] ) && 'update_order_review' == $_REQUEST['wc-ajax'] )
				
			) {
				// Rates might not be set yet if on the cart page, so calculate shipping
				WC()->cart->calculate_shipping();
			}
		}

		
		foreach ( $packages as $package_key => $package ) {

			$index++;
			
			if ( empty( $package['rates'] ) ) { 
				continue; 
			}

			$shipping_rate = $package['rates'][ $chosen_shipping_methods[ $package_key ] ];

			if ( empty( $shipping_rate ) ) { 
				continue; 
			}

			if ( !isset( $chosen_shipping_methods[ $package_key ] ) || 'use_my_shipper' !== substr( $chosen_shipping_methods[ $package_key ], 0, 14 ) ) {
				$shipping_rate->add_meta_data( $shipping_rate->get_label(), '' );
				$shipping_rate->add_meta_data( $labels['ship_acct'], '' );
				$shipping_rate->add_meta_data( $labels['ship_note'], '' );
				$shipping_rate->add_meta_data( __( 'Items', 'woocommerce' ), '' );
				continue; 
			}
			
			// This plugin's cart button JS "Update Shipper Data" sends only one selection for the package 
			if ( isset( $_REQUEST['action'] ) && 'update_ums_shipper' == $_REQUEST['action'] ) { 
				$shipper = isset( $_POST['my_shipper'][$index] ) ? $_POST['my_shipper'][$index] : false; 
				$shipper_number = isset( $_POST['use_my_shipper'][$index] ) ? $_POST['use_my_shipper'][$index] : false; 
				$shipper_note = isset( $_POST['use_my_shipper_note'][$index] ) ? $_POST['use_my_shipper_note'][$index] : false; 
				
			// Checkout JS is handled by WC, which sends all options on the page. 
			} else { 
				
				// Check each "use_my_shipper_instance" array for this package to get the instance ID of each instance 
				
				// Get the values for set the instance and process into the session
				if ( !empty( $_REQUEST['shipping_method'][ $index ] ) ) { 
					$parts = explode( ':', $_REQUEST['shipping_method'][ $index ] );
					if ( !empty( $parts[1] ) ) { 
						$the_instance_id = $parts[1];
					}
				}

				if ( empty( $the_instance_id ) ) { 
					
					$the_instance_id = $package_key;
					
					if ( !empty( $_REQUEST['shipping_method'][ $the_instance_id ] ) ) { 
						$parts = explode( ':', $_REQUEST['shipping_method'][ $the_instance_id ] );
						if ( !empty( $parts[1] ) ) { 
							$the_instance_id = $parts[1];
						}
					}
				}

				if ( empty( $the_instance_id ) ) { 
					continue; 
				}
				
				$shipper = isset( $_REQUEST['my_shipper'][$the_instance_id][ $package_key ] ) ? $_REQUEST['my_shipper'][$the_instance_id][ $package_key ] : false; 
				$shipper_number = isset( $_REQUEST['use_my_shipper'][$the_instance_id][ $package_key ] ) ? $_REQUEST['use_my_shipper'][$the_instance_id][ $package_key ] : false; 
				$shipper_note = isset( $_REQUEST['use_my_shipper_note'][$the_instance_id][ $package_key ] ) ? $_REQUEST['use_my_shipper_note'][$the_instance_id][ $package_key ] : false; 
			}

			if ( empty( $shipper ) || empty( $shipper_number ) ) {
				//if ( !empty( @$shipping_rate->meta_data[ $shipping_rate->get_label() ] ) ) { 
					//$shipping_rate->add_meta_data( $shipping_rate->get_label(), '' );
					$shipping_rate->add_meta_data( $labels['ship_acct'], '' );
					//$shipping_rate->add_meta_data( $labels['ship_note'], '' );
					//$shipping_rate->add_meta_data( __( 'Items', 'woocommerce' ), '' );
				//}
				continue;
			}
			
			if ( !empty( $shipper ) ) { 
				//$shipping_rate->add_meta_data( $shipping_rate->get_label(), $shipper, true );
				$shipping_rate->add_meta_data( $labels['ship_name'], $shipper, true );
			}
			
			if ( !empty( $shipper_number ) ) { 
				$shipping_rate->add_meta_data( $labels['ship_acct'], $shipper_number, true );
				
			} else { 
				$shipping_rate->add_meta_data( $labels['ship_acct'], '', true );
			}

			$items = array(); 
			
			// Add packages items 
			foreach( $package['contents'] as $item ) { 
				$items[] = $item['data']->get_name() . ' &times; ' . $item['quantity'];
			}
			
			if ( !empty( $items ) ) { 
				$shipping_rate->add_meta_data( __( 'Items', 'woocommerce' ), implode( ', ', $items ), true );
			} else { 
				$shipping_rate->add_meta_data( __( 'Items', 'woocommerce' ), '', true );
			}

			if ( !empty( $shipper_note ) ) { 
				$shipping_rate->add_meta_data( $labels['ship_note'], $shipper_note, true );
			} else { 
				$shipping_rate->add_meta_data( $labels['ship_note'], '', true );
			}
		
			$package['rates'][ $chosen_shipping_methods[ $package_key ] ] = $shipping_rate;

			WC()->session->set( 'ums_shipping_meta_' . $package_key . '_' . $shipping_rate->get_instance_id(), array( 'index' => $index, 'instance_id' => $shipping_rate->get_instance_id(), 'rate_id' => $shipping_rate->get_id(), 'shipper'=> $shipper, 'number' => $shipper_number, 'note' => $shipper_note ) );
					
			WC()->session->save_data();

		}


		if ( isset( $_REQUEST['action'] ) && 'update_ums_shipper' == $_REQUEST['action'] ) { 
			wp_send_json( array( 'result' => 'success' ) );
		}
		
		return $packages; 
	}

	function show_my_shipper( $order_id = null ) { 
		global $post, $wpdb, $ign_shipper_displayed; 

		//if ( $ign_shipper_displayed )
		//	return;
		
		$order = wc_get_order( $order_id );
		
		$meta = $order->get_meta_data(); 
		
		$data = array();

		foreach( $meta as $k => $d ) {
			$vals = $d->get_data();
			if ( 'my_shipper' === substr( $vals['key'], 0, 10 ) ) {
				$data[] = array( 
					'meta_key' => $vals['key'],
					'meta_value' => $vals['value'],
				);
			}
		}
		
		//$sql = 'select meta_key, meta_value from ' . $wpdb->postmeta . ' where post_id=' . $order_id . ' and meta_key like "my_shipper%" ';		
		//$data = $wpdb->get_results( $sql, ARRAY_A );

		if ( empty( $data ) ) { 
			return; 
		}
		
		$shippers = array(); 

		for( $i = 0; $i < count( $data ); $i++ ) { 
			if ( substr( $data[$i]['meta_key'], 0, 15 ) == 'my_shipper_acct' ) { 
				$index = str_replace( 'my_shipper_acct_', '', $data[$i]['meta_key'] );
				if ( empty( $index ) ) { 
					$index = 0;
				}
				$shippers[ $index ]['acct'] = $data[$i]['meta_value'];
				
			} else if ( substr( $data[$i]['meta_key'], 0, 15 ) == 'my_shipper_note' ) { 
				$index = str_replace( 'my_shipper_note_', '', $data[$i]['meta_key'] );
				if ( empty( $index ) ) { 
					$index = 0;
				}
				$shippers[ $index ]['note'] = $data[$i]['meta_value'];
				
			} else if ( substr( $data[$i]['meta_key'], 0, 10 ) == 'my_shipper' ) { 
				$index = str_replace( 'my_shipper_', '', $data[$i]['meta_key'] );
				if ( empty( $index ) ) { 
					$index = 0;
				}
				$shippers[ $index ]['name'] = $data[$i]['meta_value'];
			}
		}
		
		if ( empty( $shippers ) ) {
			return;
		}
		
		foreach( $shippers as $shipper ) { 
			if ( empty( $shipper['acct'] ) ) {
				continue;
			}
			?>
			<div style="clear:both;border:1px solid #ccc; background-color:#fff; padding: 0.5em; margin-bottom:0.5em; text-align:left">
				<strong><?php _e( 'Shipper name:','woocommerce' ); ?></strong> <?php echo $shipper['name'] ?><br/>
				<strong><?php _e( 'Shipper account:','woocommerce' ); ?></strong> <?php echo $shipper['acct']; ?><br/>
				<?php if ( !empty( $shipper['note'] ) ) { ?>
				<strong><?php _e( 'Shipping note:','woocommerce' ); ?></strong>
				<br/>
				<?php echo wpautop( $shipper['note'] ); ?>
				<?php } ?>
			</div>
		<?php
		}
		//$ign_shipper_displayed = true;
	}
	
	function add_shipper_info_to_order( $order_id, $posted ) { 

		/*
		// Do not do this if the version if WC 3.0 or newer
		if ( version_compare( WOOCOMMERCE_VERSION, '3.0', '>=' ) ) { 
			return;
		}
		*/

		if ( empty( $posted ) || empty( $posted['shipping_method'] ) ) {
			return;
		}
		
		$order = wc_get_order( $order_id );
		
		$copy_to_notes = array();
		
		foreach( $posted['shipping_method'] as $index => $val ) { 
		
			if ( 'use_my_shipper' !== substr( $val, 0, 14 ) ) {
				continue;
			}

			$instance_id = explode( ':', $val );
			
			$instance_id = !empty( $instance_id[1] ) ? $instance_id[1] : false; 
			
			if ( false === $instance_id ) { 
				continue; 
			}		
			
			$shipper = isset( $_REQUEST['my_shipper'][ $instance_id ][ $index ] ) ? $_REQUEST['my_shipper'][ $instance_id ][ $index ] : '';
			
			$acct = isset( $_REQUEST['use_my_shipper'][ $instance_id ][ $index ] ) ? $_REQUEST['use_my_shipper'][ $instance_id ][ $index ] : '';
			
			$note = isset( $_REQUEST['use_my_shipper_note'][ $instance_id ][ $index ] ) ? $_REQUEST['use_my_shipper_note'][ $instance_id ][ $index ] : '';

			if ( empty( $shipper ) || empty( $acct ) ) {
				continue;
			}

			$order->update_meta_data( 'my_shipper_acct_' . $index, $acct );
			
			$order->update_meta_data( 'my_shipper_note_' . $index, $note );
			
			$order->update_meta_data( 'my_shipper_' . $index, $shipper );
			
			$order->update_meta_data( '_my_shipper_zone_instance_id_' . $index, [ $instance_id ] );
			
			//if ( empty( $instance_id ) || 0 == $inst_id ) {
			//	$settings = get_option( 'woocommerce_use_my_shipper_settings' );
			//} else { 
			//	$settings = get_option( 'woocommerce_use_my_shipper_' . $instance_id . '_settings' );
			//}

			//if ( empty( $settings ) ) {
			//	continue;
			//}
			
			//if ( !empty( $settings['copy_acct_to_note'] ) && 'yes' == $settings['copy_acct_to_note'] ) {
			//	$copy_to_notes[ $instance_id ] = true;
			//}
			
		}
		
		$order->save();
		
		$items = false; 
		
		$shippers = $order->get_items( 'shipping' ); 
		
		foreach( $shippers as $the_shipper ) { 

			if ( $instance_id !== $the_shipper->get_instance_id() ) { 
				continue; 
			}
			
			if ( 'use_my_shipper' !== substr( $the_shipper->get_method_id(), 0, 14 ) ) { 
				continue; 
			}
			
			$title = $the_shipper->get_method_title();
			
			$meta = $the_shipper->get_meta_data();
			
			foreach( $meta as $m ) { 

				if ( $title == $m->__get( 'key' ) ) { 
					$shipper = $m->__get( 'value' );
				} else if ( __( 'Shipper Acct', 'woocommerce' ) == $m->__get( 'key' ) ) { 
					$acct = $m->__get( 'value' );
				} else if ( __( 'Shipping Note', 'woocommerce' ) == $m->__get( 'key' ) ) { 
					$ship_note = $m->__get( 'value' );
				} else if ( __( 'Items', 'woocommerce' ) == $m->__get( 'key' ) ) { 
					$items = $m->__get( 'value' );
				}
			}

			$note = "\n\n" . __( "Shipper Name: ", 'woocommerce' ) . $shipper;
			$note .= "\n" . __( "Shipper Acct: ", 'woocommerce' ) . $acct;
			
			if ( !empty( $items ) ) { 
				$note .= "\n" . __( "Items: ", 'woocommerce' ) . $items;
			}
			
			if ( !empty( $note ) ) { 
				$note .= "\n" . __( "Note: ", 'woocommerce' ) . $ship_note;
			}
			
			// Get existing note and add to it.
			
			// 3.2 and newer: 
			if ( function_exists( 'wc_create_order_note' ) ) { 
				wc_create_order_note( $order_id, $note );
			} else { 
				$order = wc_get_order( $order_id );
				$order->add_order_note( $note );
			}
		}
	}

	function maybe_add_to_emails( $order, $sent_to_admin = false, $plain_text = false, $email = false ) { 

		if ( empty( $order ) ) {
			return;
		}
			
		if ( method_exists( $order, 'get_id' ) )
			$oid = $order->get_id();
		else 
			$oid = $order->id;

		if ( empty( $oid ) ) { 
			return;
		}
		
		// Get shipping line items 
		$shippers = $order->get_items( 'shipping' );

		if ( empty( $shippers ) ) {
			return; 
		}
		
		$labels = array( 
			'ship_name' => __( 'Shipper Name', 'woocommerce' ),
			'ship_acct' => __( 'Shipper Acct', 'woocommerce' ),
			'ship_note' => __( 'Shipping Note', 'woocommerce' ),
		);
		
		foreach( $shippers as $shipper ) { 

			if ( empty( $shipper->get_method_id() ) || 'use_my_shipper' !== $shipper->get_method_id() ) { 
				continue;
			}
			
			$title = $shipper->get_method_title();

			$meta = $shipper->get_meta_data();
			
			$shipper_name = __( 'Unknown', 'woocommerce' );
			
			foreach( $meta as $k => $m ) {
			
				if ( $labels['ship_name'] == $m->__get( 'key' ) ) { 
					$shipper_name = $m->__get( 'value' );
				} else if ( __( 'Items', 'woocommerce' ) == $m->__get( 'key' ) ) { 
					$items = $m->__get( 'value' );
				} else if ( $labels['ship_acct'] == $m->__get( 'key' ) ) {  
					$acct = $m->__get( 'value' );
				} else if ( $labels['ship_note'] == $m->__get( 'key' ) ) {  
					$note = $m->__get( 'value' );
				}
			}

			$zone_id = method_exists( $shipper, 'get_instance_id' ) ? $shipper->get_instance_id() : false;
			
			if ( false === $zone_id ) { 
				$zone_id = $order->get_meta( $oid, '_my_shipper_zone_instance_id', true );
			}

			if ( !isset( $zone_id ) || false === $zone_id ) { 
				$settings = get_option( 'woocommerce_use_my_shipper_settings' );
			} else { 
				$settings = get_option( 'woocommerce_use_my_shipper_' . $zone_id . '_settings' );
			}

			if ( empty( $settings ) ) { 
				continue;
			}
				
			if ( empty( $settings['add_to_email'] ) || 'yes' !== $settings['add_to_email'] ) { 
				continue;
			}
				
			if ( empty( $acct ) || empty( $title ) ) { 
				continue;
			}

			if ( false == $plain_text ) { 

				?>
				<p><strong><?php _e( 'Shipping:', 'woocommerce' ); ?></strong> <?php echo $title; ?></p>
				<p><strong><?php _e( 'Shipper:', 'woocommerce' ); ?></strong> <?php echo $shipper_name; ?></p>
				<p><strong><?php _e( 'Acct:', 'woocommerce' ); ?></strong> <?php echo $acct; ?></p>
				<p><strong><?php _e( 'Items:', 'woocommerce' ); ?></strong> <?php echo $items; ?></p>
				<?php 
				
				if ( !empty( $note ) ) { 
					?>
					<p><strong><?php _e( 'Shipping Note:', 'woocommerce' ); ?></strong></p>
					<?php echo wpautop( $note ); ?></p>
					<?php
				}
			} else { 
			
				?>
				<?php _e( 'Shipping:', 'woocommerce' ); ?></strong> <?php echo $title . "\n"; ?>
				<?php _e( 'Shipper:', 'woocommerce' ); ?></strong> <?php echo $shipper . "\n"; ?>
				<?php _e( 'Acct:', 'woocommerce' ); ?></strong> <?php echo $acct . "\n"; ?>
				<?php _e( 'Items:', 'woocommerce' ); ?></strong> <?php echo $items . "\n"; ?>
				<?php 
				
				if ( !empty( $note ) ) { 
					?>
					<?php _e( 'Shipping Note:', 'woocommerce' ); ?>
					<?php echo "\n"; ?>
					<?php echo $note . "\n" ?>
					<?php
				}
			}
		}

	}

	function ign_my_shipper_action_links( $links ) {

		$plugin_links = array(
			'<a href="https://ignitewoo.com/ignitewoo-software-documentation/" target="_blank">' . __( 'Docs', 'woocommerce' ) . '</a>',
			'<a href="https://ignitewoo.com/" target="_blank">' . __( 'More Extensions', 'woocommerce' ) . '</a>',
			'<a href="https://ignitewoo.com/contact-us/" target="_blank">' . __( 'Support', 'woocommerce' ) . '</a>',
		);

		return array_merge( $plugin_links, $links );
	}
}

new IGN_Use_My_Shipper_Base();

/*********** END **************/




































































































if ( ! function_exists( 'ignitewoo_queue_update' ) )
	require_once( dirname( __FILE__ ) . '/ignitewoo_updater/ignitewoo_update_api.php' );

$this_plugin_base = plugin_basename( __FILE__ );

add_action( "after_plugin_row_" . $this_plugin_base, 'ignite_plugin_update_row', 1, 2 );


ignitewoo_queue_update( plugin_basename( __FILE__ ), 'be99e94cf92f28b5af3d848efd9bac73', '10773' );

