<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class WC_USE_MY_SHIPPER extends WC_Shipping_Method {

	public static $inst_id; 
	public static $the_label; 
	public $shipper_label;
	public $allowed_shippers;
	public $shipping_fee;
	public $shipping_fee_amount;
	public $add_to_email;
	public $copy_acct_to_note;
	public $shipping_note_required;

	function __construct( $instance_id = 0 ) {
	
		$this->id = 'use_my_shipper';
		$this->instance_id  = absint( $instance_id );

		self::$inst_id = $this->instance_id;

		$this->supports = array(
			'shipping-zones', // zone-settings
			'instance-settings',
			'instance-settings-modal',
		);
		
		$this->method_title = __( 'Use My Shipper', 'woocommerce' );
		
		$this->init();
	}
	
	function init() {

		$this->instance_form_fields = $this->get_form_fields();
	
		$this->set_settings();
			
		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
		
		// Move to the main plugin file for WC 4.x
		//add_action( 'woocommerce_before_checkout_form', array( $this, 'scripts' ), 1 );
	}

	function process_admin_options() {
		parent::process_admin_options();
		$this->set_settings();
	}
	
	function set_settings() { 

		$this->enabled			= $this->get_option( 'enabled' );
		$this->title 			= $this->get_option( 'title' );
		$this->availability 		= $this->get_option( 'availability' );
		$this->countries 			= $this->get_option( 'countries' );
		$this->shipper_label		= $this->get_option( 'shipper_label' );
		self::$the_label 			= $this->shipper_label;
		$this->allowed_shippers 	= $this->get_option( 'allowed_shippers' );
		$this->shipping_fee		= $this->get_option( 'shipping_fee' );
		$this->shipping_fee_amount	= $this->get_option( 'shipping_fee_amount' );
		$this->add_to_email 		= $this->get_option( 'add_to_email' );
		$this->copy_acct_to_note 	= $this->get_option( 'copy_acct_to_note' );
		$this->shipping_note_required = $this->get_option( 'shipping_note_required' );
	}
	
	function get_form_fields() {

		$fields = array(
			
			'title' => array(
							'title' 		=> __( 'Method Title', 'woocommerce' ),
							'type' 			=> 'text',
							'description' 	=> __( 'This controls the title which the user sees during checkout.', 'woocommerce' ),
							'default'		=> __( 'Use Your Shipper Account', 'woocommerce' ),
							'desc_tip'		=> true,
						),
			'shipper_label' => array(
							'title' 		=> __( 'Field Label', 'woocommerce' ),
							'type' 			=> 'text',
							'description' 	=> __( 'The label displayed with the shipper account input field', 'woocommerce' ),
							'default'		=> __( 'Shipper Account Number', 'woocommerce' ),
							'desc_tip'		=> true,
						),
			'allowed_shippers' => array(
							'title' 		=> __( 'Allowed Shippers', 'woocommerce' ),
							'type' 			=> 'text',
							'description' 	=> __( 'A comma separated list of allowed shippers', 'woocommerce' ),
							'default'		=> 'Fedex, UPS',
							'desc_tip'		=> true,
						),
			'shipping_note' => array(
							'title' 		=> __( 'Enable Shipping Note', 'woocommerce' ),
							'label'		=> __( 'Enable', 'woocommerce' ),
							'type' 		=> 'checkbox',
							'description' 	=> __( 'Enable a shipping comment box to appear beneath the list of shippers. This field would be optional and allow the shopper to enter a message to you.', 'woocommerce' ),
							'default'		=> 'no',
							'desc_tip'		=> true,
						),
			'shipping_note_required' => array(
							'title' 		=> __( 'Make Shipping Note Required', 'woocommerce' ),
							'label'		=> __( 'Enable', 'woocommerce' ),
							'type' 		=> 'checkbox',
							'description' 	=> __( 'If the shipping note is enabled then by default it is an optional field. Check this box to make that field required.', 'woocommerce' ),
							'default'		=> 'no',
							'desc_tip'		=> true,
						),
			'shipping_note_placeholder' => array(
							'title' 		=> __( 'Shipping Note Placeholder', 'woocommerce' ),
							//'label'		=> __( 'Enable', 'woocommerce' ),
							'type' 		=> 'text',
							'description' 	=> __( 'If the shipping note is enabled then use this text as the placeholder message displayed with the input field', 'woocommerce' ),
							'default'		=> '',
							'desc_tip'		=> true,
						),
			/* DEPRECATED 
			'copy_acct_to_note' => array(
							'title' 		=> __( 'Copy Shipping Acct to Notes', 'woocommerce' ),
							'label'		=> __( 'Enable', 'woocommerce' ),
							'type' 		=> 'checkbox',
							'description' 	=> __( 'When enabled, any shipping account number provided by the customer will be copied to the "Notes" field in the order. This is useful when exporting order data to 3rd party shipping software.', 'woocommerce' ),
							'default'		=> 'no',
							'desc_tip'		=> true,
						),
			*/
			'shipping_fee' => array(
							'title' 		=> __( 'Add Handling Fee', 'woocommerce' ),
							'type' 		=> 'select',
							'description' 	=> __( 'Add a handling for this shipping method', 'woocommerce' ),
							'default'		=> '',
							'options' 		=> array(
										'' => __( 'None', 'woocommerce' ),
										'fixed_amount' => __( 'Fixed amount', 'woocommerce' ),
										'percentage' => __( 'Percentage of cart subtotal', 'woocommerce' ),
										),
							'desc_tip'		=> true,
						),
			'shipping_fee_amount' => array(
							'title' 		=> __( 'Handling Fee Amount', 'woocommerce' ),
							'type' 		=> 'text',
							'description' 	=> __( 'Enter the amount. If you selected percentage as your fee type only enter the numeric percentage amount, do not enter a percent symbol.', 'woocommerce' ),
							'default'		=> '',
							'desc_tip'		=> true,
						),
			'shipping_fee_taxable' => array(
							'title' 		=> __( 'Handling Fee Taxable', 'woocommerce' ),
							'type' 		=> 'select',
							'description' 	=> __( 'Enter the amount. If you selected percentage as your fee type only enter the numeric percentage amount, do not enter a percent symbol.', 'woocommerce' ),
							'default'		=> 'no',
							'options' 		=> array(
								'yes' => __( 'Yes', 'woocommerce' ),
								'no' => __( 'No', 'woocommerce' ),
							),
							'desc_tip'		=> true,
						),
			'add_to_email' => array(
							'title' 		=> __( 'Add to order emails', 'woocommerce' ),
							'type' 			=> 'checkbox',
							'label' 		=> __( 'Enable', 'woocommerce' ),
							'default' 		=> 'no',
							'description' 	=> __( 'Insert shipper, account, and note into order emails for customers and admins ', 'woocommerce' ),
							'desc_tip'		=> true,
						),
		);
		
		if ( empty( $this->instance_id ) ) { 
			$enabled = array( 'enabled' => array(
					'title' 		=> __( 'Enable/Disable', 'woocommerce' ),
					'type' 			=> 'checkbox',
					'label' 		=> __( 'Enable This Method', 'woocommerce' ),
					'default' 		=> 'no'
				)
			);
			$fields = array_merge( $enabled, $fields );
		}
		
		return $fields;
	}

	public static function ign_use_my_shipper_new_way( $method, $index ) { 
		
		$method_id = $method->get_id();
		
		if ( empty( $method_id ) ) {
			return;
		}
		
		if ( 'use_my_shipper' !== substr( $method_id, 0, 14 ) ) { 
			return;
		}
		
		ob_start();
		
		self::ign_use_my_shipper( $method, $index );
		
		$form = ob_get_clean();
		
		echo $form;
	}
	
	public static function ign_use_my_shipper( $method, $package_index = 0 ) { 
		global $woocommerce;
		
		// Check shipping destination, if not set do not show the shipping option yet
		// as that can confuse various customers. 
		
		if ( method_exists( $woocommerce->customer, 'get_shipping_postcode' ) )
			$dest_zip = $woocommerce->customer->get_shipping_postcode();
		else if ( isset( $_SESSION['customer']['shipping_postcode'] ) )
			$dest_zip = $_SESSION['customer']['shipping_postcode'];

		/* Some countries do not have states
		if ( method_exists( $woocommerce->customer, 'get_shipping_state' ) )
			$dest_state = $woocommerce->customer->get_shipping_state();
		else if ( isset( $_SESSION['customer']['shipping_state'] ) )
			$dest_state = $_SESSION['customer']['shipping_state'];
		*/

		if ( method_exists( $woocommerce->customer, 'get_shipping_country' ) )
			$dest_country = $woocommerce->customer->get_shipping_country();
		else if ( isset( $_SESSION['customer']['shipping_country'] ) )
			$dest_country = $_SESSION['customer']['shipping_country'];

		if ( empty( $dest_country ) || empty( $dest_zip ) ) { 
			//return;
		}
		
		$packages = WC()->shipping->get_packages();

		//$keys = array_keys( $packages );

		//$key = $keys[ $package_index ];
		
		$rates = $packages[ $package_index ]['rates'];
		
		if ( !empty( $rates ) ) { 
			$rate_keys = array_keys( $rates );
		} else { 
			$rate_keys = array();
		}
	
		foreach( $rate_keys as $rk ) { 
			if ( 'use_my_shipper' == substr( $rk, 0, 14 ) ) { 
				$package_rate_object =  $packages[ $package_index ]['rates'][ $rk ]; 
				break;
			}
		}

		/*
		if ( !empty( $package_rate_object ) && method_exists( $package_rate_object, 'get_instance_id' ) ) {
			self::$inst_id = $package_rate_object->get_instance_id();
		} else if ( !empty( $package_rate_object ) ) { 
			self::$inst_id = $package_rate_object->instance_id;
		}
		*/
		
		//if ( empty( $package_rate_object ) ) { 
			self::$inst_id = $method->get_instance_id();
		//}
		
		if ( empty( self::$inst_id ) || 0 == self::$inst_id ) { 
			$settings = get_option( 'woocommerce_use_my_shipper_settings' );
		} else {
			$settings = get_option( 'woocommerce_use_my_shipper_' . self::$inst_id . '_settings' );
		}

		if ( empty( $settings ) ) { 
			return;
		}
		
		$shippers = explode( ',', $settings['allowed_shippers'] );

		// Allow filter the list of shippers.
		// The list is an array.
		/** Example: 
		 *
		 * $shippers = array( 
		 *	'Fedex',
		 *	'UPS',
		 *	'DHL'
		 * );
		 */
		$shippers = apply_filters( 'ignitewoo_use_my_shipper_shippers_list', $shippers, $package_index, $packages );
		
		if ( empty( $shippers ) ) { 
			return;
		}
		
		$acct = isset( $_REQUEST['use_my_shipper'] ) ? trim( $_REQUEST['use_my_shipper'] ) : '';
		
		$selected = null;
		
		$note = '';
		
		if ( !empty( $_REQUEST['post_data'] ) ) { 
		
			$args = wp_parse_args( $_REQUEST['post_data'] );
			
			if ( !empty( $args['my_shipper'][ self::$inst_id ] ) ) {
				$selected = $args['my_shipper'][ self::$inst_id ];
			} else {
				$selected = null;
			}
				
			if ( !empty( $args['use_my_shipper'][ self::$inst_id ] ) ) { 
				$acct = $args['use_my_shipper'][ self::$inst_id ];
			}
			
			if ( !empty( $args['use_my_shipper_note'][ self::$inst_id ] ) ) { 
				$note = $args['use_my_shipper_note'][ self::$inst_id ];
			}
		}

		$rates = isset( $packages[ $package_index ]['rates'] ) ? $packages[ $package_index ]['rates'] : array();
	
		foreach( $rates as $rate ) { 
		
			if ( $rate->get_id() !== $method->get_id() ) { 
				continue; 
			}			
			
			if ( 'use_my_shipper' !== substr( $rate->get_id(), 0, 14  ) ) { 
				continue; 
			}

			$shipper_data = WC()->session->get( 'ums_shipping_meta_' . $package_index . '_' . $rate->get_instance_id() );

			if ( !empty( $shipper_data ) ) { 
				$acct = $shipper_data['number']; 
				$note = $shipper_data['note']; 
				$selected = $shipper_data['shipper']; 
			} else { 
				$acct = '';
				$note = '';
				$selected = '';
			}
		
			$meta = $rate->get_meta_data(); 
				
			foreach( $meta as $k => $v ) { 
				if ( 'shipper' == $k ) { 
					$selected = $v; 
				} else if ( 'shipper_number' == $k ) { 
					$acct = $v; 
				}  else if ( 'shipper_note' == $k ) { 
					$note = $v; 
				}
			}
		}

		//if ( count( $packages[0]['rates'] ) <= 1 ) 
			$css = 'display:table-row';
		//else 
		//	$css = 'display:none';
		
		/* DEPRECATED: But leave it in case we decide to revert.
		?>
		<tr id="use_my_shipper" style="<?php echo $css ?>">
			<th><?php echo $settings['shipper_label'] ?></th>
			<td>
				<div style="margin-bottom: 0.5em">
				<select class="my_shipper" name="my_shipper" style="width:200px">
					<?php foreach( $shippers as $s ) { ?>
					<option value="<?php echo $s ?>" <?php selected( $s, $selected, true ) ?>><?php echo $s ?></option>
					<?php } ?>
				</select>
				</div>
				<input class="input-text" type="text" name="use_my_shipper" value="<?php echo $acct ?>" placeholder="<?php _e( 'Account number', 'woocommerce') ?>">

				<?php if ( !empty( $settings['shipping_note'] ) && 'yes' == $settings['shipping_note'] ) { ?>
				
				<textarea class="input-text shipping_note" name="use_my_shipper_note" placeholder="<?php _e( 'Shipping instructions...', 'woocommerce') ?>" style="width:98%;margin-top:5px;min-height:80px;font-size:100%"></textarea>
				
				<?php } ?>
			</td>
		</tr>
		<?php
		*/

		?>
		
		<table  id="use_my_shipper" style="display:none"> 
			<tr style="<?php echo $css ?>">
				<th><?php echo $settings['shipper_label'] ?></th>
			</tr>
			<tr id="use_my_shipper_row" style="<?php echo $css ?>">
				<td>
				
					<input type="hidden" name="use_my_shipper_instance[<?php echo $package_index; ?>][]" data-index="<?php echo $package_index ?>" value="<?php echo $method->get_instance_id() ?>">
				
					<div style="margin-bottom: 0.5em">
						<select class="my_shipper shipper_name" name="my_shipper[<?php echo $method->get_instance_id(); ?>][<?php echo $package_index; ?>]" data-index="<?php echo $package_index ?>" style="width:200px">
							<?php foreach( $shippers as $s ) { ?>
							<option value="<?php echo trim( $s ) ?>" <?php selected( trim( $s ), $selected, true ) ?>><?php echo $s ?></option>
							<?php } ?>
						</select>
					</div>
					
					<input class="input-text shipper_number" type="text" name="use_my_shipper[<?php echo $method->get_instance_id(); ?>][<?php echo $package_index; ?>]" data-index="<?php echo $package_index ?>" value="<?php echo trim( $acct ) ?>" placeholder="<?php _e( 'Account number', 'woocommerce') ?>">

					<?php if ( !empty( $settings['shipping_note'] ) && 'yes' == $settings['shipping_note'] ) { ?>
					
						<?php $placeholder = isset( $settings['shipping_note_placeholder'] ) ? $settings['shipping_note_placeholder'] : __( 'Shipping instructions...', 'woocommerce'); ?>
					
						<textarea class="input-text shipper_note" name="use_my_shipper_note[<?php echo $method->get_instance_id(); ?>][<?php echo $package_index; ?>]" data-index="<?php echo $package_index ?>" placeholder="<?php echo $placeholder ?>" style="width:98%;margin-top:5px;min-height:80px;font-size:100%"><?php echo $note ?></textarea>
					
					<?php } ?>
					
					
					<?php if ( is_cart() ) { ?>
						<p class="ums_shipper_button_label"><?php _e( 'Enter the shipper info and click Update Shipper Data button', 'woocommerce' ); ?></p>
						<p class="ums_shipper_button_wrap"><input type="button" class="button ums_shipper_button" value="<?php _e( 'Update Shipper Data', 'woocommerce' ) ?>"></p>
					<?php } ?>
					
				</td>
			</tr>
		</table>
		<?php
	}
	
	function get_currenct_settings() { 
		return $this->instance_settings;
	}
	
	public static function after_checkout_validation( $data, $errors ) {
		if ( empty( $_REQUEST['shipping_method'] ) ) { 
			return;
		}
		
		// We have a list of "Use My Shipper" selections for each cart package.
		// Check each one to ensure there is at least an account number present if Use My Shipper is the selection shipping method for the package
		foreach ( $_REQUEST['shipping_method'] as $index => $shipper ) {

			if ( 'use_my_shipper' !== substr( $shipper, 0, 14 ) ) {
				continue;
			}

			$instance_id = explode( ':', $shipper );
			
			$instance_id = !empty( $instance_id[1] ) ? $instance_id[1] : false; 

			if ( false === $instance_id ) { 
				continue; 
			}		

			$_REQUEST['use_my_shipper'][ $instance_id ][ $index ] = trim( $_REQUEST['use_my_shipper'][ $instance_id ][ $index ] );
			
			if ( empty( $_REQUEST['use_my_shipper'][ $instance_id ][ $index ] ) ) {

				// Find the instance ID so we can load the settings for it and get the label text
				// because for some damn reason WC()->shipping is entirely empty at this point in the flow
				// so we don't have access to shipping packages
				
				// Assume there is a package with an index key of 0, there should be, but there may not be !
				$session_key  = 'shipping_for_package_' . $index;
				$stored_rates = WC()->session->get( $session_key );

				// DEPRECATED: Formerly for backward compat, we now require zones 
				//if ( empty( $stored_rates['rates']['use_my_shipper']->instance_id ) ) {
				//	$settings = get_option( 'woocommerce_use_my_shipper_settings' );
				//} else {
					//$settings = get_option( 'woocommerce_use_my_shipper_' . $stored_rates['rates'][ $s ] . '_settings' );
				//}
				
				$settings = get_option( 'woocommerce_use_my_shipper_' . $instance_id . '_settings' );
			
				$label = $settings['shipper_label'];
	
				$message = sprintf( __( '<strong>%s</strong> is required', 'woocommerce' ), $label );
				$message = apply_filters( 'ums_checkout_error_message', $message );
				$errors->add( 'shipping', $message );
				
			}
			
			if ( !empty( $instance_id ) ) {
				$settings = get_option( 'woocommerce_use_my_shipper_' . $instance_id . '_settings' );
			}
			
			$note = isset( $_REQUEST['use_my_shipper_note'][ $instance_id ][ $index ] ) ? trim( $_REQUEST['use_my_shipper_note'][ $instance_id ][ $index ] ) : false; 
			
			if ( ( !empty( $settings['shipping_note_required'] ) && 'yes' == $settings['shipping_note_required'] ) && empty( $note ) ) {
				$errors->add( 'shipping', __( '<strong>Shipping Instructions</strong> are required', 'woocommerce' ) );
			}
		}
		
	}
	
	/* Deprecated Jan 2025 in favor of the after_checkout_validation() function above, which sets errors instead of adding notices,
	and runs with a different hook of this in the main plugin file:
	add_action( 'woocommerce_after_checkout_validation', array( 'WC_USE_MY_SHIPPER', 'after_checkout_validation' ), 1, 2 );
	public static function my_shipper_review() { 
		global $woocommerce;

		$shipper = array(); 
		
		if ( empty( $_REQUEST['shipping_method'] ) ) { 
			return;
		}

		// We have a list of "Use My Shipper" selections for each cart package.
		// Check each one to ensure there is at least an account number present if Use My Shipper is the selection shipping method for the package
		foreach ( $_REQUEST['shipping_method'] as $index => $shipper ) {

			if ( 'use_my_shipper' !== substr( $shipper, 0, 14 ) ) {
				continue;
			}

			$instance_id = explode( ':', $shipper );
			
			$instance_id = !empty( $instance_id[1] ) ? $instance_id[1] : false; 

			if ( false === $instance_id ) { 
				continue; 
			}		

			$_REQUEST['use_my_shipper'][ $instance_id ][ $index ] = trim( $_REQUEST['use_my_shipper'][ $instance_id ][ $index ] );
			
			if ( empty( $_REQUEST['use_my_shipper'][ $instance_id ][ $index ] ) ) {

				// Find the instance ID so we can load the settings for it and get the label text
				// because for some damn reason WC()->shipping is entirely empty at this point in the flow
				// so we don't have access to shipping packages
				
				// Assume there is a package with an index key of 0, there should be, but there may not be !
				$session_key  = 'shipping_for_package_' . $index;
				$stored_rates = WC()->session->get( $session_key );

				// DEPRECATED: Formerly for backward compat, we now require zones 
				//if ( empty( $stored_rates['rates']['use_my_shipper']->instance_id ) ) {
				//	$settings = get_option( 'woocommerce_use_my_shipper_settings' );
				//} else {
					//$settings = get_option( 'woocommerce_use_my_shipper_' . $stored_rates['rates'][ $s ] . '_settings' );
				//}
				
				$settings = get_option( 'woocommerce_use_my_shipper_' . $instance_id . '_settings' );
			
				$label = $settings['shipper_label'];
	
				$message = sprintf( __( '<strong>%s</strong> is required', 'woocommerce' ), $label );
				$message = apply_filters( 'ums_checkout_error_message', $message );
				wc_add_notice( $message, 'error' );
				
			}
			
			if ( !empty( $instance_id ) ) {
				$settings = get_option( 'woocommerce_use_my_shipper_' . $instance_id . '_settings' );
			}
			
			$note = isset( $_REQUEST['use_my_shipper_note'][ $instance_id ][ $index ] ) ? trim( $_REQUEST['use_my_shipper_note'][ $instance_id ][ $index ] ) : false; 
			
			if ( ( !empty( $settings['shipping_note_required'] ) && 'yes' == $settings['shipping_note_required'] ) && empty( $note ) ) {

				wc_add_notice( __( '<strong>Shipping Instructions</strong> are required', 'woocommerce' ), 'error' );
			}
		}
	}
	*/
	
	public function admin_options() {
		?>		
		<h3><?php _e( 'Shipping', 'woocommerce' ); ?></h3>
		
		<table class="form-table">
		<?php
			$this->generate_settings_html();
		?>
		</table> 
		<script>
		jQuery( document ).ready( function($) { 
			$( '#woocommerce_use_my_shipper_shipping_fee' ).on( 'change', function() {
				if ( '' == $( this ).val() )
					$( '#woocommerce_use_my_shipper_shipping_fee_amount' ).closest( 'tr' ).hide();
				else 
					$( '#woocommerce_use_my_shipper_shipping_fee_amount' ).closest( 'tr' ).show();
			})
			$( '#woocommerce_use_my_shipper_shipping_fee' ).trigger( 'change' );
		})
		</script>
		<?php
	}


	function is_available( $package ) {

		if ( 'no' == $this->enabled ) {
			return false;
		}
		
		$shippers = explode( ',', $this->allowed_shippers );

		$shippers = array_filter( $shippers );
		
		if ( empty( $shippers ) || count( $shippers ) <= 0 ) { 
			return false;
		}
		
		return true;
	}


	function calculate_shipping( $package = array() ) {
		global $woocommerce;

		// Display on cart page? 
		//if ( ! empty( $_REQUEST['update_cart'] ) ) return false;
		
		// Check shipping destination, if not set do not show the shipping option yet
		// as that can confuse various customers. 
		
		if ( method_exists( $woocommerce->customer, 'get_shipping_postcode' ) )
			$dest_zip = $woocommerce->customer->get_shipping_postcode();
		else if ( isset( $_SESSION['customer']['shipping_postcode'] ) )
			$dest_zip = $_SESSION['customer']['shipping_postcode'];

		// DEPRECATED
		/* Some countries do not have states
		if ( method_exists( $woocommerce->customer, 'get_shipping_state' ) )
			$dest_state = $woocommerce->customer->get_shipping_state();
		else if ( isset( $_SESSION['customer']['shipping_state'] ) )
			$dest_state = $_SESSION['customer']['shipping_state'];
		*/

		/*
		if ( method_exists( $woocommerce->customer, 'get_shipping_country' ) )
			$dest_country = $woocommerce->customer->get_shipping_country();
		else if ( isset( $_SESSION['customer']['shipping_country'] ) )
			$dest_country = $_SESSION['customer']['shipping_country'];

		if ( empty( $dest_country ) || empty( $dest_zip ) ) { 
			return;
		}
		*/
		
		$cost = 0;

		$taxable = false;
		
		if ( !empty( $this->get_option( 'shipping_fee_amount' ) ) && !empty( $this->get_option('shipping_fee') ) ) { 
			if ( 'fixed_amount' == $this->get_option('shipping_fee') ) {
				$cost = floatval( $this->get_option( 'shipping_fee_amount' ) );
				
			} else if ( 'percentage' == $this->get_option('shipping_fee' ) ) { 
				$subtotal = WC()->cart->cart_contents_total;
				$cost = $subtotal * ( $this->get_option( 'shipping_fee_amount' ) / 100 );
			}
			
			if ( !empty( $cost ) ) { 
				if ( !empty( $this->get_option( 'shipping_fee_taxable' ) ) && 'yes' == $this->get_option( 'shipping_fee_taxable' ) ) {
					$taxable = true;
				}
			}
		}

		$args = array(
			//'id' 	=> $this->id,
			'label' 	=> $this->title,
			'cost' 	=> $cost,
			'taxes'	=> $taxable,
			'package' 	=> $package,
		);

		$this->add_rate( $args );
	}
}
