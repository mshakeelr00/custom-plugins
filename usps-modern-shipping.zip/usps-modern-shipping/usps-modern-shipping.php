<?php
/**
 * Plugin Name: USPS Modern Shipping for WooCommerce
 * Description: Display USPS shipping rates using USPS OAuth 2.0 API and WooCommerce custom shipping method.
 * Version: 1.0
 * Author: ChatGPT
 */

if (!defined('ABSPATH')) exit;

// Register shipping method
add_action('woocommerce_shipping_init', 'usps_custom_shipping_method_init');

function usps_custom_shipping_method_init() {
    if (!class_exists('WC_Shipping_Method')) return;

    class WC_Usps_Custom_Shipping extends WC_Shipping_Method {

        public function __construct() {
            $this->id                 = 'usps_custom';
            $this->method_title       = __('USPS Shipping (Modern)', 'usps');
            $this->method_description = __('Get USPS rates using OAuth 2.0 API.', 'usps');
            $this->enabled            = 'yes';
            $this->title              = __('USPS Shipping', 'usps');
            $this->init();
        }

        public function init() {
            $this->init_form_fields();
            $this->init_settings();
        }

        public function calculate_shipping($package = []) {
            $client_id     = 'YOUR_CONSUMER_KEY';
            $client_secret = 'YOUR_CONSUMER_SECRET';
            $origin_zip    = '90210'; // Replace with your origin zip

            $token = $this->get_usps_oauth_token($client_id, $client_secret);
            if (!$token) return;

            $weight_oz = 16; // Default to 16oz
            $dest_zip  = $package['destination']['postcode'];

            $request_body = [
                "rateOptions" => [
                    "carrierId" => "USPS",
                    "packageDetails" => [[
                        "fromZIPCode" => $origin_zip,
                        "toZIPCode"   => $dest_zip,
                        "weight" => [
                            "unitOfMeasurement" => "OZ",
                            "value"             => $weight_oz
                        ],
                        "dimensions" => [
                            "length" => 10,
                            "width"  => 6,
                            "height" => 2,
                            "unitOfMeasurement" => "IN"
                        ],
                        "packageType" => "PACKAGE"
                    ]]
                ]
            ];

            $rates = $this->get_usps_rates($token, $request_body);
            if (!isset($rates['rateOptions'][0]['rates'])) return;

            foreach ($rates['rateOptions'][0]['rates'] as $rate) {
                $this->add_rate([
                    'id'    => sanitize_title($rate['serviceName']),
                    'label' => $rate['serviceName'],
                    'cost'  => floatval($rate['totalCharge']['amount'])
                ]);
            }
        }

        private function get_usps_oauth_token($client_id, $client_secret) {
            $response = wp_remote_post('https://api.usps.com/oauth2/v3/token', [
                'headers' => [
                    'Authorization' => 'Basic ' . base64_encode("$client_id:$client_secret"),
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                ],
                'body' => [
                    'grant_type' => 'client_credentials',
                ],
            ]);

            if (is_wp_error($response)) return null;

            $body = json_decode(wp_remote_retrieve_body($response), true);
            return $body['access_token'] ?? null;
        }

        private function get_usps_rates($token, $payload) {
            $response = wp_remote_post('https://api.usps.com/shipping/v2/rates/quotes', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json',
                ],
                'body' => json_encode($payload),
            ]);

            if (is_wp_error($response)) return null;

            return json_decode(wp_remote_retrieve_body($response), true);
        }
    }
}

add_filter('woocommerce_shipping_methods', function($methods) {
    $methods['usps_custom'] = 'WC_Usps_Custom_Shipping';
    return $methods;
});
